/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleshootinggame;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JLabel;
import javax.swing.SwingWorker;

/**
 *
 * @author owoye001
 */
public class WelcomeScreen extends ShootingGame {
    
    static int num = 1;

    private Task task;

    JLabel enter;

    JLabel exit;

    JLabel gun;

    class Task extends SwingWorker<Void, Void> {

        /**
         * Main task. Executed in background thread.
         */
        @Override
        public Void doInBackground() {
            int progress = 0;
            setProgress(0);
            Loading.currentProgress = Loading.ProgressBars[5].getImage();
            progress += 50;
            setProgress(50);
            SimpleShootingGame.cl.show(SimpleShootingGame.mainJPanel, "2"); //show welcome screen first   
            setProgress(Math.min(progress, 50));
            return null;
        }

        /**
         * Executed in event dispatching thread
         */
        @Override
        public void done() {
            setCursor(Cursor.getDefaultCursor()); // turn off the wait cursor
        }
    }

    public WelcomeScreen() {
        
        final int ButtonWidth = 200;
        final int ButtonHeight = 150;

        
        
        /*
        //Loading from jar
        
        //System.out.println((getClass().getResource(SimpleShootingGame.loadfiles("///OtherImages\\WelcomeImages\\welcome.jpg"))).toString());
        images[0] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//WelcomeImages//welcome.jpg")));
        images[1] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//WelcomeImages//stormtroopers.jpg")));

        images[2] = new ImageIcon((SimpleShootingGame.loadfiles("//ButtonImages//enter.jpg")));
        images[3] = new ImageIcon((SimpleShootingGame.loadfiles("//ButtonImages//entero.jpg")));
        images[4] = new ImageIcon((SimpleShootingGame.loadfiles("//ButtonImages//exit.jpg")));
        images[5] = new ImageIcon((SimpleShootingGame.loadfiles("//ButtonImages//exito.jpg")));
        images[6] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//WelcomeImages//StageImageF.jpg")));

        //Loading Stages here 
        images[7] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//StageImages//stage1.jpg")));
        images[8] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//StageImages//stage2.jpg")));
        images[9] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//StageImages//stage3.jpg")));
        currentProgress = SimpleShootingGame.ProgressBars[0].getImage();

        guns = new ImageIcon[3]; //loading gun images
        guns[0] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Guns//gun1.gif")));
        guns[1] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Guns//gun1.gif")));
        guns[2] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Guns//gun1.gif")));
        
        //Loading Fruits here
        fruits[0] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Fruits//banana.gif")));
        fruits[1] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Fruits//redapple.gif")));
        fruits[2] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Fruits//orange.gif")));
        fruits[3] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Fruits//watermelon.gif")));
        fruits[4] = new ImageIcon((SimpleShootingGame.loadfiles("//OtherImages//Fruits//deadfruit.gif"))); */

        JLabel welcome = new JLabel();
        JLabel progress = new JLabel();

        //loaded and sizing buttons 
        enter = new JLabel();
        exit = new JLabel();
        gun = new JLabel();
        JLabel st = new JLabel();
        JLabel stageImage = new JLabel(); //the basic stage image. 

        welcome.setBounds(30 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 30 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 900 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 580 * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        enter.setBounds(30 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 580 * (int) SimpleShootingGame.screenSize.getHeight() / 768, ButtonWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, ButtonHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        exit.setBounds(1100 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 580 * (int) SimpleShootingGame.screenSize.getHeight() / 768, ButtonWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, ButtonHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        st.setBounds(930 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, -40 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 427 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 640 * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        gun.setBounds(41 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 611 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 215 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 123 * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        progress.setBounds(280 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 620 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 696 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 143 * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        stageImage.setBounds(30 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 29 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 964 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 559 * (int) SimpleShootingGame.screenSize.getHeight() / 768); 
        //resizing based on container

        for (int i = 2; i < 4; i++) {
            Loading.images[i] = SimpleShootingGame.LoadImageByContainer(enter, Loading.images[i]);
        }

        for (int i = 4; i < 6; i++) {
            Loading.images[i] = SimpleShootingGame.LoadImageByContainer(exit, Loading.images[i]);
        }

        for (int i = 0; i < 6; i++) {
            Loading.ProgressBars[i] = SimpleShootingGame.LoadImageByContainer(progress, Loading.ProgressBars[i]);
        }

        for (int i = 7; i < 10; i++) {
            Loading.images[i] = SimpleShootingGame.LoadImageByContainer(stageImage, Loading.images[i]); //resizing STAGE IMAGE here
        }

        for (int i = 0; i < 3; i++) {
            Loading.guns[i] = SimpleShootingGame.LoadImageByContainer(gun, Loading.guns[i]); //resizing image failed here
        }

        welcome = SimpleShootingGame.LoadImage(welcome, Loading.images[0]);
        st = SimpleShootingGame.LoadImage(st, Loading.images[1]);
        //progress = ShootingGame.LoadImage(progress, SimpleShootingGame.ProgressBars[0]);

        enter = SimpleShootingGame.ReStyleButtons(enter, 2); //adds mouseover effect
        exit = SimpleShootingGame.ReStyleButtons(exit, 4); //adds mouseover effect

        MouseListener handlerM = new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent me) {

                Loading.sounds[0].play(); //button click

                if (me.getSource().equals(enter)) {
                    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
                // Instances of javax.swing.SwingWorker are not reusuable, so
                    // we create new instances as needed.
                    task = new Task();

                    PropertyChangeListener prop = (PropertyChangeEvent pce) -> {
                        if ("progress".equals(pce.getPropertyName())) {
                            int progress1 = (Integer) pce.getNewValue();
                            Loading.currentProgress = Loading.ProgressBars[progress1 / 10].getImage();
                            num = progress1 / 10;
                        }
                    };

                    task.addPropertyChangeListener(prop);
                    task.execute();

                //real deal
                    //try {Thread.sleep(2000);} catch (InterruptedException ex) {}
                } else if (me.getSource().equals(exit)) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ex) {
                    } //makes the thread sleep for 500 seconds.
                    System.exit(0);
                }
            }

            @Override
            public void mousePressed(MouseEvent me) {}

            @Override
            public void mouseReleased(MouseEvent me) {}

            @Override
            public void mouseEntered(MouseEvent me) {}
            
            @Override
            public void mouseExited(MouseEvent me) {}

        };

        exit.addMouseListener(handlerM);

        enter.addMouseListener(handlerM);

        //adding it to the frame 
        add(welcome);
        add(st);
        add(enter);
        add(exit);
        add(progress);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(Loading.currentProgress, 280 * (int) SimpleShootingGame.screenSize.getWidth() / 1366,
                620 * (int) SimpleShootingGame.screenSize.getHeight() / 768,
                696 * (int) SimpleShootingGame.screenSize.getWidth() / 1366,
                143 * (int) SimpleShootingGame.screenSize.getHeight() / 768, Color.white, null);
        repaint();

    }
}
