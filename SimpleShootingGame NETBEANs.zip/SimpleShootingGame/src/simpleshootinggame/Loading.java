/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleshootinggame;

import jaco.mp3.player.MP3Player;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.SwingWorker;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;

/**
 *
 * /**
 *
 * @author owoye001
 */
public class Loading extends JFrame {

    static JProgressBar progress;
    
    Task task;
    
    static ImageIcon images[]; //welcome screeen images

    static ImageIcon Lives[];

    static ImageIcon Ammo[];

    static ImageIcon guns[];

    static ImageIcon fruits[];

    static Image currentProgress;

    static Cursor custom; //custom cursor

    static ImageIcon ProgressBars[];

    static MP3Player[] sounds;
    
    private final Dimension screenSize;

    class Task extends SwingWorker<Void, Void> {

        /**
         * Main task. Executed in background thread.
         */
        @Override
        public Void doInBackground() {
            int progress = 0;
            setProgress(0);
            
            ProgressBars = new ImageIcon[6];
            sounds = new MP3Player[5];
            
            progress +=2;
            setProgress(progress);

            images = new ImageIcon[10]; //load images required for the welcome screen and the stages 
            
            progress +=2;
            setProgress(progress);
            
            fruits = new ImageIcon[5]; //fruit initialtion array

            progress +=2;
            setProgress(progress);
            
            guns = new ImageIcon[3]; //loading gun images

            progress +=2;
            setProgress(progress);
            
            images[0] = new ImageIcon(getClass().getResource("OtherImages/WelcomeImages/welcome.jpg"));
            
            progress +=2;
            setProgress(progress);
            images[1] = new ImageIcon(getClass().getResource("OtherImages/WelcomeImages/stormtroopers.jpg"));
            
            progress +=2;
            setProgress(progress);

            images[2] = new ImageIcon(getClass().getResource("ButtonImages/enter.jpg"));
            
            progress +=2;
            progress +=2;
            setProgress(progress);

            images[2] = new ImageIcon(getClass().getResource("ButtonImages/enter.jpg"));
            
            setProgress(progress);
            images[3] = new ImageIcon(getClass().getResource("ButtonImages/entero.jpg"));
            
            progress +=2;
            setProgress(progress);
            images[4] = new ImageIcon(getClass().getResource("ButtonImages/exit.jpg"));
            
            progress +=2;
            setProgress(progress);
            images[5] = new ImageIcon(getClass().getResource("ButtonImages/exito.jpg"));
            
            progress +=2;
            setProgress(progress);
            images[6] = new ImageIcon(getClass().getResource("OtherImages/WelcomeImages/StageImageF.jpg"));
            
            progress +=2;
            setProgress(progress);

            //Loading Stages here 
            images[7] = new ImageIcon(getClass().getResource("OtherImages/StageImages/stage1.jpg"));
            
            progress +=2;
            setProgress(progress);
            
            images[8] = new ImageIcon(getClass().getResource("OtherImages/StageImages/stage2.jpg"));
            
            progress +=2;
            setProgress(progress);
            
            images[9] = new ImageIcon(getClass().getResource("OtherImages/StageImages/stage3.jpg"));
            
            progress +=2;
            setProgress(progress);

            guns[0] = new ImageIcon(getClass().getResource("OtherImages/Guns/gun1.gif"));
            
            progress +=2;
            setProgress(progress);
            guns[1] = new ImageIcon(getClass().getResource("OtherImages/Guns/gun1.gif"));
            
            progress +=2;
            setProgress(progress);
            guns[2] = new ImageIcon(getClass().getResource("OtherImages/Guns/gun1.gif"));
            
            progress +=2;
            setProgress(progress);

            //Loading Fruits here
            fruits[0] = new ImageIcon(getClass().getResource("OtherImages/Fruits/banana.gif"));
            
            progress +=2;
            setProgress(progress);
            fruits[1] = new ImageIcon(getClass().getResource("OtherImages/Fruits/redapple.gif"));
            
            progress +=2;
            setProgress(progress);
            fruits[2] = new ImageIcon(getClass().getResource("OtherImages/Fruits/orange.gif"));
            
            progress +=2;
            setProgress(progress);
            fruits[3] = new ImageIcon(getClass().getResource("OtherImages/Fruits/watermelon.gif"));
            
            progress +=2;
            setProgress(progress);
            fruits[4] = new ImageIcon(getClass().getResource("OtherImages/Fruits/deadfruit.gif"));
            
            progress +=2;
            setProgress(progress);

            ProgressBars[0] = new ImageIcon(getClass().getResource("OtherImages/ProgressImage/0.jpg"));
            
            progress +=2;
            setProgress(progress);
            
            ProgressBars[1] = new ImageIcon(getClass().getResource("OtherImages/ProgressImage/10.jpg"));
            
            progress +=2;
            setProgress(progress);
            ProgressBars[2] = new ImageIcon(getClass().getResource("OtherImages/ProgressImage/20.jpg"));
            
            progress +=2;
            setProgress(progress);
            
            ProgressBars[3] = new ImageIcon(getClass().getResource("OtherImages/ProgressImage/50.jpg"));
            
            progress +=2;
            setProgress(progress);
            ProgressBars[4] = new ImageIcon(getClass().getResource("OtherImages/ProgressImage/75.jpg"));
            
            progress +=2;
            setProgress(progress);
            
            ProgressBars[5] = new ImageIcon(getClass().getResource("OtherImages/ProgressImage/100.jpg"));
            
            progress +=2;
            setProgress(progress);

            currentProgress = ProgressBars[0].getImage();
            
            progress +=2;
            setProgress(progress);

            sounds[0] = new MP3Player(new File(SoundDirectory("button.mp3"))); //load the button sound
            setProgress(progress);
            
            
            progress +=2;
            sounds[1] = new MP3Player(new File(SoundDirectory("shoot.mp3"))); //load the shoot sound
            
            progress +=2;
            setProgress(progress);
            
            sounds[2] = new MP3Player(new File(SoundDirectory("reload.mp3"))); //load the reload sound
            
            progress +=2;
            setProgress(progress);
            
            sounds[3] = new MP3Player(new File(SoundDirectory("empty.mp3"))); //load the reload sound
            
            progress +=2;
            setProgress(progress);
            
            sounds[4] = new MP3Player(new File(SoundDirectory("victory.mp3"))); //load the reload sound
            
            progress +=2;
            setProgress(progress);

            custom = Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("OtherImages/MouseImage/Icon.gif")).getImage(), new Point(10, 15), "shoot");

            progress +=2;
            setProgress(progress);
            
            //Loading lives and ammo objects
            Loading.Ammo = new ImageIcon[22]; //creating saves for ammo objects
            for (int i = 0; i < 22; i++) {
                //Ammo[i] = new ImageIcon(getClass().getResource("OtherImages//Ammo//" + i + ".jpg"));
                Ammo[i] = new ImageIcon((getClass().getResource("OtherImages/Ammo/" + i + ".jpg")));
                
            }

            progress +=10;
            setProgress(progress);
                    
            //Loading live images here.
            Lives = new ImageIcon[5]; //creating saves for live objects 
            int livenum = 0;
            for (int i = 0; i < 5; i++) {
                //Lives[i] = new ImageIcon(getClass().getResource("OtherImages//Lives//" + livenum + ".jpg"));
                Lives[i] = new ImageIcon((getClass().getResource("OtherImages/Lives/" + livenum + ".jpg")));
                livenum = livenum + 25;
            }
            
            progress +=10;
            setProgress(progress);

            //--------------------------
            setProgress(Math.min(progress, 100));
            return null;
        }

        /**
         * Executed in event dispatching thread
         */
        @Override
        public void done() {
            setCursor(Cursor.getDefaultCursor()); // turn off the wait cursor
            setVisible(false);
            SwingUtilities.invokeLater(() -> {
                new SimpleShootingGame();
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Loading();
        });
    }

    public final String SoundDirectory(String variable) {
        String soundbutt;
        String path;

        File f = new File(System.getProperty("java.class.path"));
        File dir = f.getAbsoluteFile().getParentFile();
        path = dir.toString();
        soundbutt = "\\Sounds\\" + variable; //button.mp3
        return path + soundbutt;
    }

    public Loading() {
        
        screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize(); //screensize of the monitor. 
        progress = new JProgressBar();
        progress.setValue(0);
        progress.setBackground(Color.black);
        progress.setForeground(Color.green);
        progress.setStringPainted(true);
        
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        // Instances of javax.swing.SwingWorker are not reusuable, so
        // we create new instances as needed.
        task = new Task();

        PropertyChangeListener prop = (PropertyChangeEvent pce) -> {
            if ("progress".equals(pce.getPropertyName())) {
                int progress1 = (Integer) pce.getNewValue();
                progress.setValue(progress1);
            }
        };

        task.addPropertyChangeListener(prop);
        task.execute();

        setUndecorated(true);
        setLayout(null);
        setLocation ((int)((screenSize.getWidth()-300)/2), (int)((screenSize.getHeight()-100)/2));
        setSize(300, 100);
        progress.setBounds(0, 0, 300, 100);
        add(progress);
        setVisible(true);
    }
}
