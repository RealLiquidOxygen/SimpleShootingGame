/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleshootinggame;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 *
 * @author owoye001
 */
public class BasicStage extends ShootingGame {

    public static int currentHealthNumber = 4; //full health
    public static int currentStageNumber = 9; //stage 1 - 7, stage 2 - 8, stage 3 - 9
    public static int currentAmmoNumber = 21; //full ammo
    public static int gunNumber = 0;

    //timer unhide fruit and leave fruit as dead. 
    static Timer unhidefruit;
    static Timer makefruitdeads;

    //x's and Y'S cordinates of fruits 
    public ImageIcon fruit1 = Loading.fruits[0];
    public ImageIcon fruit2 = Loading.fruits[1];
    public ImageIcon fruit3 = Loading.fruits[2];
    public ImageIcon fruit4 = Loading.fruits[3];
    public ImageIcon deadfruit = Loading.fruits[4];

    //random fruit location generator 
    Random random = new Random();

    //default fruit paint locations
    public int fruit1X = 0;
    public int fruit1Y = 0;
    public int fruit2X = 0;
    public int fruit2Y = 0;
    public int fruit3X = 0;
    public int fruit3Y = 0;
    public int fruit4X = 0;
    public int fruit4Y = 0;

    public static int score = 0; //game score 

    //hits a fruit
    public static int fruitHit = 1; //two misses lose a life
    
    //default max and min for fruit location on X-AXIS
    int MaxX = 850 ; 
    int MinX = 98;

    //defualt max and min for fruit location on Y-AXI
    int MaxY = 450;
    int MinY = 190;
    
    //default mouse-shoot region X-Y cordinate
    int MouseYMax = 587;
    int MouseYMin = 29;
    int MouseXMax = 993;
    int MouseXMin = 30;

    //defualt fruit state is 1
    public static int fruit1state = 1; //1 alive, 2 dead, 3 disappeared
    public static int fruit2state = 1; //1 alive, 2 dead, 3 disappeared
    public static int fruit3state = 1; //1 alive, 2 dead, 3 disappeared
    public static int fruit4state = 1; //1 alive, 2 dead, 3 disappeared

    //default fruit size
    int fruitWidth = 173;
    int fruitHeight = 160;

    public static int hitCount = 0;
    public static int missCount = 0;

    static Timer movef; //timer to move fruits around.

    JLabel exiter;
    JLabel fruit;

    public ImageIcon currentstagePicture; //stage picture. 
    public ImageIcon stageStructure; //stage background
    final CardLayout cardlayout = new CardLayout();
    public Image currentHealth = Loading.Lives[currentHealthNumber].getImage(); //current player health image
    public Image currentAmmo = Loading.Ammo[currentAmmoNumber].getImage(); //current ammo image
    public static Image currentGun; //image of current gun, can be changed. But not programmed
   

    public BasicStage() {

        //get size of screen where application is running 
//        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
//        int width = gd.getDisplayMode().getWidth();
//        int height = gd.getDisplayMode().getHeight();

//        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//        double width = screenSize.getWidth();
//        double height = screenSize.getHeight();
        
        
        currentGun = Loading.guns[gunNumber].getImage(); //current gun image load to ariable

        final int ButtonWidth = (int)((200.0/ 1366.0) * SimpleShootingGame.screenSize.getWidth()) ;
        final int ButtonHeight = (int)((150.0/768.0) * SimpleShootingGame.screenSize.getHeight());
        
        //Screen size adjustment
        double width = SimpleShootingGame.screenSize.getWidth();
        double height = SimpleShootingGame.screenSize.getHeight();
   
       MaxX = (int)((650.0 / 1366.0) * width);
       MinX = (int)((30.0/1366.0) * width);
  
       MaxY = (int) ((300.0/768.0) * height);
       MinY = (int) ((30.0/768.0) * height);
       
        MouseYMax =  (int)((740.0/768.0) * height);
        MouseYMin = (int)((29.0/768.0) * height);
        MouseXMax = (int)((1250.0 / 1366.0) * width);
        MouseXMin = (int)((30.0 / 1366.0) * width);
        
        fruitWidth = (int)((73.0/1366.0) * width);
        fruitHeight = (int)((60.0/768.0) * height);
        
        exiter = new JLabel();
        fruit = new JLabel();
        JLabel basicstage = new JLabel();
        //JLabel stagepicture = new JLabel();

        basicstage.setBounds(0 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 0 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 1366 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 768 * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        exiter.setBounds(1100 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 590 * (int) SimpleShootingGame.screenSize.getHeight() / 768, ButtonWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, ButtonHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768);
        fruit.setBounds(0 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 0 * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth, fruitHeight);
        //stagepicture.setSize(SimpleShootingGame.screenSize);

        //resing fruits here
        Loading.fruits[0] = SimpleShootingGame.LoadImageByContainer(fruit, Loading.fruits[0]); //fruit 1
        Loading.fruits[1] = SimpleShootingGame.LoadImageByContainer(fruit, Loading.fruits[1]); //fruit 2
        Loading.fruits[2] = SimpleShootingGame.LoadImageByContainer(fruit, Loading.fruits[2]); //fruit 3
        Loading.fruits[3] = SimpleShootingGame.LoadImageByContainer(fruit, Loading.fruits[3]); //fruit 4

        //basicstage = SimpleShootingGame.LoadImage(basicstage, Loading.images[6]); //returns Jlabel FAILED LOAD
        stageStructure = SimpleShootingGame.LoadImageByContainer(basicstage, Loading.images[6]); //stage 1

        //currentstagePicture = SimpleShootingGame.LoadImageByContainer(stagepicture, currentstagePicture);
        exiter = SimpleShootingGame.ReStyleButtons(exiter, 4); //adds mouseover effect

        //adding it to the jpanel 
        add(exiter);
        //add(basicstage);
        //add(stagepicture);
        //add(mainstage); //ADDING THE MAIN JPANEL TO THE JFRAME HERE. THE GAME JFRAME

        //if the fruit has dissappeared, make it alive again
        ActionListener unhidefruits = (ActionEvent ae) -> {

            if (fruit1state == 3) {
                fruit1state = 1;
            } else if (fruit2state == 3) {
                fruit2state = 1;
            } else if (fruit3state == 3) {
                fruit3state = 1;
            } else if (fruit4state == 3) {
                fruit4state = 1;
            }

        };

        ActionListener makefruitdead = (ActionEvent ae) -> {
            if (fruit1state == 2) {
                fruit1state = 3;
            } else if (fruit2state == 2) {
                fruit2state = 3;
            } else if (fruit3state == 2) {
                fruit3state = 3;
            } else if (fruit4state == 2) {
                fruit4state = 3;
            }
        };

        makefruitdeads = new Timer(300, makefruitdead);

        makefruitdeads.start();

        unhidefruit = new Timer(900, unhidefruits);

        unhidefruit.start();

        ActionListener movefruits = (ActionEvent ae) -> {

            do {
                fruit1X = random.nextInt(MaxX);
            } while (fruit1X <= MinX);

            do {
                fruit1Y = random.nextInt(MaxY);
            } while (fruit1Y <= MinY);

            do {
                fruit2X = random.nextInt(MaxX);
            } while (fruit2X <= MinX);

            do {
                fruit2Y = random.nextInt(MaxY);
            } while (fruit2Y <= MinY || fruit2Y == fruit1Y);

            do {
                fruit3X = random.nextInt(MaxX);
            } while (fruit3X <= MinX);

            do {
                fruit3Y = random.nextInt(MaxY);
            } while (fruit3Y <= MinY);

            do {
                fruit4X = random.nextInt(MaxX);
            } while (fruit4X <= MinX);

            do {
                fruit4Y = random.nextInt(MaxY);
            } while (fruit4Y <= MinY);
        };

        movef = new Timer(1500, movefruits);
        movef.start();

        MouseMotionListener handlerMotion = new MouseMotionListener() {

            @Override
            public void mouseDragged(MouseEvent me) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseMoved(MouseEvent me) {
                if (me.getX() >= MouseXMin && me.getY() >= MouseYMin && me.getX() <= MouseXMax && me.getY() <= MouseYMax) {
                    setCursor(Loading.custom);
                    //setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
                } else {
                    setCursor(null);
                }
            }
        ;

        };
        
        MouseListener handlerMouse = new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent me) {
                //System.out.print (me.getX() + " " + me.getY());
                //System.out.print(fruit1X + " " +fruit1Y);
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                if ((me.getX() >= MouseXMin && me.getY() >= MouseYMin && me.getX() <= MouseXMax && me.getY() <= MouseYMax) & (SwingUtilities.isLeftMouseButton(me))) {

                    if (currentAmmoNumber >= 1) {
                        Loading.sounds[1].play();
                        currentAmmoNumber -= 1;

                        FruitBulletCollisionDetection(me);

                        NoFruitBulletCollision();

                        //change stage every 500 points
                        if (score % 500 == 0) {
                            Loading.sounds[4].play(); //level up
                            if (currentStageNumber == 9) {
                                currentStageNumber = 7;
                            } else {
                                currentStageNumber += 1;
                            }

                        }

                    } else { //out of bullet
                        Loading.sounds[3].play();
                    }
                } else if ((me.getX() >= MouseXMin && me.getY() >= MouseYMin && me.getX() <= MouseXMax && me.getY() <= MouseYMax) & (SwingUtilities.isRightMouseButton(me))) {
                    Loading.sounds[2].play();
                    currentAmmoNumber = 21; //full ammo
                }
            }

            public void NoFruitBulletCollision() {
                if (fruit1state == 1 && fruit2state == 1 && fruit3state == 1 && fruit4state == 1) //missed all fruits
                {
                    //loss a life if you miss two time
                    if (fruitHit >= 1) {
                        fruitHit = fruitHit - 1;
                    } else {
                        if (currentHealthNumber > 0) {
                            ReduceHealth();
                        } else {
                            EndGame();
                        }
                        fruitHit = 1; //reset fruit hit
                    }
                }
            }

            public void EndGame() {
                //stopping all timers and swapping cards
                movef.stop();
                unhidefruit.stop();
                makefruitdeads.stop();
                GameOver.statistics.setText("Score: " + score);
                SimpleShootingGame.cl.show(SimpleShootingGame.mainJPanel, "3"); //show welcome screen first  //exit game 
            }

            @Override
            public void mousePressed(MouseEvent me) {}

            @Override
            public void mouseReleased(MouseEvent me) {}

            @Override
            public void mouseEntered(MouseEvent me) {}

            @Override
            public void mouseExited(MouseEvent me) {}

        };

        addMouseMotionListener(handlerMotion);
        addMouseListener(handlerMouse);

    }
   

    public void FruitBulletCollisionDetection(MouseEvent me) {
        
        if ((me.getX() >= fruit1X * (int) SimpleShootingGame.screenSize.getWidth() 
                / 1366 && me.getX() <= fruit1X * (int) SimpleShootingGame
                        .screenSize.getWidth() / 1366 + fruitWidth) && (me.getY() >= 
                fruit1Y * (int) SimpleShootingGame.screenSize.getHeight() / 768 && me.getY() <= fruit1Y * (int) SimpleShootingGame.screenSize.getHeight() / 768 + fruitHeight)) {
            fruit1state = 2;
            score = score + 20;
        }
        if ((me.getX() >= fruit2X * (int) SimpleShootingGame.screenSize.getWidth() 
                / 1366 && me.getX() <= fruit2X * (int) SimpleShootingGame.
                        screenSize.getWidth() / 1366 + fruitWidth) && 
                (me.getY() >= fruit2Y * (int) SimpleShootingGame.screenSize.getHeight() / 
                768 && me.getY() <= fruit2Y * (int) SimpleShootingGame.screenSize.getHeight() / 768 + fruitHeight)) {
            fruit2state = 2;
            score = score + 20;
        }
        if ((me.getX() >= fruit3X * (int) SimpleShootingGame.screenSize.getWidth() 
                / 1366 && me.getX() <= fruit3X * (int) SimpleShootingGame.screenSize
                        .getWidth() / 1366 + fruitWidth) && (me.getY() >= fruit3Y 
                * (int) SimpleShootingGame.screenSize.getHeight() / 768 
                && me.getY() <= fruit3Y * (int) SimpleShootingGame.screenSize.getHeight() / 768 
                + fruitHeight)) {
            fruit3state = 2;
            score = score + 20;
        }
        if ((me.getX() >= fruit4X * (int) SimpleShootingGame.screenSize.getWidth() / 
                1366 && me.getX() <= fruit4X * (int) SimpleShootingGame.screenSize
                        .getWidth() / 1366 + fruitWidth) && (me.getY() >= fruit4Y 
                * (int) SimpleShootingGame.screenSize.getHeight() / 768 && me.getY() <= 
                fruit4Y * (int) SimpleShootingGame.screenSize.getHeight() / 768 + fruitHeight)) {
            fruit4state = 2;
            score = score + 20;
        }
    }

    public void ReduceHealth() {
        currentHealthNumber = currentHealthNumber - 1;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        currentHealth = Loading.Lives[currentHealthNumber].getImage();
        currentAmmo = Loading.Ammo[currentAmmoNumber].getImage();
        currentGun = Loading.guns[gunNumber].getImage();
        currentstagePicture = Loading.images[currentStageNumber];

        PaintStageAndTools(g);
        PaintFruits(g);
        repaint();
    }

    public void PaintFruits(Graphics g) {
        //painting fruits here
        //1 alive, 2 dead, 3 disappeared
        if (fruit1state == 1) {
            g.drawImage(fruit1.getImage(), fruit1X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit1Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);
        } else if (fruit1state == 2) {
            g.drawImage(deadfruit.getImage(), fruit1X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit1Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);

        } else if (fruit1state == 3) {
            //no drawing.
        }

        if (fruit2state == 1) {
            g.drawImage(fruit2.getImage(), fruit2X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit2Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);
        } else if (fruit2state == 2) {
            g.drawImage(deadfruit.getImage(), fruit2X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit2Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);

        } else if (fruit2state == 3) {
            //no drawing.
        }

        if (fruit3state == 1) {
            g.drawImage(fruit3.getImage(), fruit3X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit3Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);
        } else if (fruit3state == 2) {
            g.drawImage(deadfruit.getImage(), fruit3X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit3Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);
        } else if (fruit3state == 3) {
            //no drawing.
        }

        if (fruit4state == 1) {
            g.drawImage(fruit4.getImage(), fruit4X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit4Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);
        } else if (fruit4state == 2) {
            g.drawImage(deadfruit.getImage(), fruit4X * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruit4Y * (int) SimpleShootingGame.screenSize.getHeight() / 768, fruitWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, fruitHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);
        } else if (fruit4state == 3) {
            //no drawing.
        }
    }

    public void PaintStageAndTools(Graphics g) {
        g.drawImage(stageStructure.getImage(), 0, 0, 1366 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 768 * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);

        g.drawImage(currentAmmo, 300 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 634 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 700 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 89 * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);

        g.drawImage(currentGun, 41 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 611 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 215 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 123 * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);

        g.drawImage(currentstagePicture.getImage(), MouseXMin, MouseYMin, 964 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 559 * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);

        g.drawImage(currentHealth, 590 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 28 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 402 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 53 * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);
    }

    public static void resetit() {
        hitCount = 0;
        missCount = 0;
        fruit1state = 1; //1 alive, 2 dead, 3 disappeared
        fruit2state = 1; //1 alive, 2 dead, 3 disappeared
        fruit3state = 1; //1 alive, 2 dead, 3 disappeared
        fruit4state = 1; //1 alive, 2 dead, 3 disappeared
        fruitHit = 1; //two misses lose a life
        score = 0; //game score 
        currentHealthNumber = 4; //full health
        currentStageNumber = 9; //stage 1 - 7, stage 2 - 8, stage 3 - 9
        currentAmmoNumber = 21; //full ammo
        gunNumber = 0;
        movef.start();
        unhidefruit.start();
        makefruitdeads.start();
    }

}
