/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleshootinggame;

import java.awt.Color;
import javax.swing.JPanel;

/**
 *
 * @author owoye001
 */
public class ShootingGame extends JPanel  {

    
    public ShootingGame()
            {
                setSize(SimpleShootingGame.screenSize);
                setLayout(null);
                setBackground(Color.black);
                setLocation(0,0);
            }
    
}
