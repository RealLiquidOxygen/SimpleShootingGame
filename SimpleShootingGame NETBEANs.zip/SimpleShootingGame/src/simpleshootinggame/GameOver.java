/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleshootinggame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author owoye001
 */
public class GameOver extends ShootingGame {
    static JLabel statistics;
    JButton playagain;
    JLabel exiter;
     final int ButtonWidth = 200;
     int ButtonHeight = 150;
    public static Image currentGun;
    public GameOver()
    {
        exiter = new JLabel();
        playagain = new JButton();
        statistics = new JLabel ();
        
        exiter.setBounds(1100 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 590 * (int) SimpleShootingGame.screenSize.getHeight() / 768, ButtonWidth * (int) SimpleShootingGame.screenSize.getWidth() / 1366, ButtonHeight * (int) SimpleShootingGame.screenSize.getHeight() / 768);

        
        statistics.setFont(new java.awt.Font("Comic Sans MS", 0, 34)); // NOI18N
        statistics.setForeground(Color.yellow);
        statistics.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        statistics.setText("Score: 0");
        statistics.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        statistics.setBounds(307 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 269 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 373 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 82 * (int) SimpleShootingGame.screenSize.getHeight() / 768);
    
        playagain.setBackground(new java.awt.Color(51, 102, 0));
        playagain.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        playagain.setForeground(Color.white);
        playagain.setText("Play Again");
        playagain.setBounds(400* (int) SimpleShootingGame.screenSize.getWidth() / 1366, 385* (int) SimpleShootingGame.screenSize.getHeight() / 768, 200* (int) SimpleShootingGame.screenSize.getWidth() / 1366, 50* (int) SimpleShootingGame.screenSize.getHeight() / 768);
        playagain.addActionListener((java.awt.event.ActionEvent evt) -> {
            BasicStage.resetit();
            SimpleShootingGame.cl.show(SimpleShootingGame.mainJPanel, "2");
      });
        
        exiter = SimpleShootingGame.ReStyleButtons(exiter, 4); //adds mouseover effect

        
        add(exiter);
        
        add(playagain);
       
        
        add (statistics);
    }
    
    @Override
    public void paintComponent(Graphics g)
    {

        super.paintComponent(g);
        
         g.drawImage(Loading.images[6].getImage(), 0, 0, 1366 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 768 * (int) SimpleShootingGame.screenSize.getHeight() / 768, this);

         g.drawImage(BasicStage.currentGun, 41 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 611 * (int) SimpleShootingGame.screenSize.getHeight() / 768, 215 * (int) SimpleShootingGame.screenSize.getWidth() / 1366, 123 * (int) SimpleShootingGame.screenSize.getHeight() / 768, null);

    }
}
