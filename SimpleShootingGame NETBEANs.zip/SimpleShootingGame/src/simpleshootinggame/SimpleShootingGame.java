/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleshootinggame;

import java.awt.Dimension;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author owoye001
 */

//code for the shooting game begins here. 

/* 
   Date: March 23, 2016
   Name: Ayodele Owoyele
*/
public class SimpleShootingGame extends JFrame {

     public static Dimension screenSize;
     
     static CardLayout cl = new CardLayout(); // creating new Card layout here.
     
     static JPanel mainJPanel;
    
    
     
    public SimpleShootingGame()
    {
         
       
       
       //System.out.println (loadfiles("\\OtherImages\\ProgressImage\\0.jpg"));
       /*
       ProgressBars[0] = new ImageIcon((loadfiles("\\OtherImages\\ProgressImage\\0.jpg")));  
       ProgressBars[1] = new ImageIcon((loadfiles("\\OtherImages\\ProgressImage\\10.jpg")));  
       ProgressBars[2] = new ImageIcon((loadfiles("\\OtherImages\\ProgressImage\\20.jpg")));  
       ProgressBars[3] = new ImageIcon((loadfiles("\\OtherImages\\ProgressImage\\75.jpg")));  
       ProgressBars[5] = new ImageIcon((loadfiles("\\OtherImages\\ProgressImage\\100.jpg"))); */
      // System.out.println (getClass().getResource("OtherImages/ProgressImage/0.jpg").toString());
       
     
       
       /*
       sounds[0] = new MP3Player(new File("Sounds//button.mp3")); //load the button sound
       sounds[1] = new MP3Player(new File("Sounds//shoot.mp3")); //load the shoot sound
       sounds[2] = new MP3Player(new File("Sounds//reload.mp3")); //load the reload sound
       sounds[3] = new MP3Player(new File("Sounds//empty.mp3")); //load the reload sound
       sounds[4] = new MP3Player(new File("Sounds//victory.mp3")); //load the reload sound */
       
       
       screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize(); //screensize of the monitor.  
        
        //creating my cards
        mainJPanel = new JPanel();
        
        mainJPanel.setLayout(cl);
        
         WelcomeScreen ws = new WelcomeScreen();
         BasicStage bs = new BasicStage();
         GameOver go = new GameOver();
         
        
        mainJPanel.add(ws,"1");
        mainJPanel.add(bs, "2");
        mainJPanel.add (go, "3");
        
        cl.show(mainJPanel, "1"); //show welcome screen first 
        
        add(mainJPanel); //ADDING THE MAIN JPANEL TO THE JFRAME HERE. THE GAME JFRAME
        
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        
        setLocationRelativeTo(null); //set in the middle of the screen here
        
        setUndecorated(true); //setting it undecorated
        
        setLocation(0,0);
    
        setSize(screenSize); //setting size to screen size. 
        
        setVisible(true); //sets the jframe visible for the main game. 
       
    }

    
    
    public static String loadfiles(String soundbutt) {
            String path;
                File f = new File(System.getProperty("java.class.path"));
                File dir = f.getAbsoluteFile().getParentFile();
                path = dir.toString();
                return path + soundbutt;
                //System.out.println ("This is dir: " + path+soundbutt );        
    }
    
    public static JLabel ReStyleButtons(JLabel restructure, int imageNumber) {
        //Button properties here
        restructure.setSize(200,200);
        restructure.setIcon(Loading.images[imageNumber]);
         restructure.addMouseListener(new MouseListener(){

            @Override
            public void mouseClicked(MouseEvent me) {
                 Loading.sounds[0].play();
               if (imageNumber==4)
               {
                   try {Thread.sleep(500);} catch (InterruptedException ex) {} //makes the thread sleep for 500 seconds.
                   System.exit(0);
               }
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                
            }

            @Override
            public void mouseEntered(MouseEvent me) {
                restructure.setIcon(Loading.images[imageNumber+1]);
            }

            @Override
            public void mouseExited(MouseEvent me) {
               restructure.setIcon(Loading.images[imageNumber]);
            }
        } );
         
         return restructure;
    }
    
    
    public static JLabel LoadImage (JLabel reformLabel, ImageIcon tutor)
    {
            Image imttut = tutor.getImage();
            Image imttutreal = imttut.getScaledInstance (reformLabel.getWidth(), reformLabel.getHeight(),java.awt.Image.SCALE_SMOOTH);
            tutor = new ImageIcon(imttutreal);
            reformLabel.setText(null);
            reformLabel.setIcon(tutor);
            return reformLabel;
    }
    
    public static ImageIcon LoadImageByContainer (JLabel reformLabel, ImageIcon tutor)
    {
            Image imttut = tutor.getImage();
            Image imttutreal = imttut.getScaledInstance (reformLabel.getWidth(), reformLabel.getHeight(),java.awt.Image.SCALE_SMOOTH);
            tutor = new ImageIcon(imttutreal);
            return tutor;
    }
    
    
}
